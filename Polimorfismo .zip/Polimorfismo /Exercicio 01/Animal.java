public class Animal {
    public void emitirSom(){
        System.out.println("Som de animal hahaha");
    }
}
