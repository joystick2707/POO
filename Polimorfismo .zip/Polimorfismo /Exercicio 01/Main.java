import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner tipo = new Scanner(System.in);
        
        Animal bicho = null;
        int opcao = 0;
        
        System.out.println("Ecolha qual animal você gostaria de ouvir: \n[1]Cachorro \n[2]Gato");
        opcao = tipo.nextInt();
        if (opcao == 1){
            bicho = new Cachorro();
            System.out.println("Cachorro selecionado");
        }
        else if(opcao == 2){
            bicho = new Gato();
            System.out.println("Gato selecionado");
        }
        else{
            System.out.println("Numero invalido, por favor tente novamente");
        }
        bicho.emitirSom();
    }
}
