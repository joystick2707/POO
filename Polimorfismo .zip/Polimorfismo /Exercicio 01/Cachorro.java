public class Cachorro extends Animal {
    @Override
    public void emitirSom(){
        System.out.println("O cachorro faz...BARK BARK!!");
    }
}
