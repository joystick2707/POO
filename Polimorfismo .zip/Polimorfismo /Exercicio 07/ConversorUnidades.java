public class ConversorUnidades {
    
    public void conventerUnidades(float centimetros){
        System.out.println("Conversor de centimetros(cm) para metros(m) selecionado");
        System.out.println("O valor " + centimetros + " em metros é: " + centimetros / 100 + "m");
    }

    public void conventerUnidades(int minutos){
        System.out.println("Conversor de horas para minutos selecionado");
        System.out.println("A quantidade " + minutos + " em horas é: " + minutos / 60 + " horas");
    }

   
}
