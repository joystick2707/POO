public class Main {
    public static void main(String[] args) {
        ConversorUnidades conv = new ConversorUnidades();
        conv.conventerUnidades(0);
        conv.conventerUnidades(120);
    }
}
