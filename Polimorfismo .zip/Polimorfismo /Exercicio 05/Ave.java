public class Ave extends Animal{
    @Override
    public void movimentar(){
        System.out.println("A ave esta voando");
    }
}
