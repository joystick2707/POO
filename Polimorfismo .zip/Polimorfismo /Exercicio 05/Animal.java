public class Animal {
    public void movimentar(){
        System.out.println("Movimentando");
    }
}
