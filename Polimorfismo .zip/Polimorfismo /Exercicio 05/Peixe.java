public class Peixe extends Animal{
    @Override
    public void movimentar(){
        System.out.println("O peixe esta nadando");
    }
}
