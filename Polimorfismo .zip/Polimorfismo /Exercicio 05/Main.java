public class Main {
    public static void main(String[] args) {
        Animal animal = null;
        int opcao = 2;

        if (opcao == 1) {
            animal = new Peixe();
        }
        else if(opcao == 2){
            animal = new Ave();
        }
        animal.movimentar();
    }
}
