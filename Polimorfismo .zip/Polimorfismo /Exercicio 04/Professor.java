public class Professor extends Pessoa{
    @Override
    public void saudacao(){
        System.out.println("Olá professor!!");
    }
}
