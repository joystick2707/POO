public class Aluno extends Pessoa{
    @Override
    public void saudacao(){
        System.out.println("Olá aluno!!");
    }
}
