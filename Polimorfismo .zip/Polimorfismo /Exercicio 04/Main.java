public class Main {
    public static void main(String[] args) {
        Pessoa pessoa = null;
        int opcao = 2;

        if (opcao == 1){
            pessoa = new Aluno();
        }
        else if(opcao == 2){
            pessoa = new Professor();
        }
        pessoa.saudacao();
    }
}
