public class Pessoa {
    
    public void saudacao(){
        System.out.println("Ola");
    }
}
