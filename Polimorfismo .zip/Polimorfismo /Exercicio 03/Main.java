public class Main {
    public static void main(String[] args) {
        Veiculo veiculo = null;
        int opcao = 1;

        if (opcao == 1){
            veiculo = new Carro();
        }
        else if(opcao == 2){
            veiculo = new Moto();
        }

        veiculo.acelerar();
    }
}
