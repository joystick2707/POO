public class Carro extends Veiculo{
    int velocidade = 0;
    
    @Override
    public void acelerar(){
        System.out.println("Carro selecionado...acelerando \nA velocidade atual do carro é de: " + (velocidade + 20) + "Km");
    }

}