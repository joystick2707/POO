public class Veiculo {
    public void acelerar(){
        System.out.println("VRUUMMMMM!!");
    }
}
