public class Calculadora {
    
    public void soma(int numero_01, int numero_02){
        //System.out.println("Soma de inteiros: \n");
        System.out.println("A soma dos numeros " + numero_01 + " + " + numero_02 + " = " + (numero_01 + numero_02));
    }

    public void soma(float numero_01f, float numero_02f){
        System.out.println("A soma dos numeros " + numero_01f + " + " + numero_02f + " = " + (numero_01f + numero_02f));
    }

    public void soma(double numero_01d, double numero_02d){
        System.out.println("A soma dos numeros " + numero_01d + " + " + numero_02d + " = " + (numero_01d + numero_02d));
    }

    public void soma(int numero_01, float numero_02f){
        System.out.println("A soma dos numeros " + numero_01 + " + " + numero_02f + " = " + (numero_01 + numero_02f));
    }

    public void soma(float numero_01f, double numero_02d){
        System.out.println("A soma dos numeros " + numero_01f + " + " + numero_02d + " = " + (numero_01f + numero_02d));
    }


}
