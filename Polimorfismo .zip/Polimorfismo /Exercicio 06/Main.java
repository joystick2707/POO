public class Main {
    public static void main(String[] args) {
        Calculadora calc_01 = new Calculadora();
        calc_01.soma(10, 10);
        calc_01.soma(10.0f, 10);
        calc_01.soma(10, 10.0f);
        calc_01.soma(10.0f, 10.0f);
    }
}
