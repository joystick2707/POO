public class Quadrado extends FormaGeometrica{
    float lado01 = 2;
    float lado02 = 2;
    float lado03 = 2;
    float lado04 = 2;

    @Override
    public void calcularArea(){
        System.out.println("Quadrado selecionado.\nPara calcular sua area precisamos somar todos os lados");
        System.out.println("A area do quadrado com os lados de valor: " + lado01 + " + " + lado02 + " + " + lado03 + " + " + lado04 + " = " + (lado01 + lado02 + lado03 + lado04));
    }
}
