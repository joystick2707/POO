public class Main {
    public static void main(String[] args) {
        FormaGeometrica forma = null;
        int opcao = 2;

        if (opcao == 1){
            forma = new Quadrado();
        }
        else if(opcao == 2){
          forma = new Circulo();  
        }

        forma.calcularArea();

    }
}
