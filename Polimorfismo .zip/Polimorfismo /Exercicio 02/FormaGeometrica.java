public class FormaGeometrica {
    public void calcularArea(){
        System.out.println("Calcular a area de uma forma geometrica");
    }
}
