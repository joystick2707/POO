public class Circulo extends FormaGeometrica{

    double PI = 3.14;
    double ValorRaio = 16.5;
    double raio = ValorRaio * ValorRaio;

    @Override
    public void calcularArea(){
        System.out.println("Circulo selecionado \nPara calcular sua area fazemos PI X raio elevado a 2");
        System.out.println("PI: " + PI + " X " + "Raio elevado a 2" + ValorRaio + " = " + (PI * raio));
    }
}
